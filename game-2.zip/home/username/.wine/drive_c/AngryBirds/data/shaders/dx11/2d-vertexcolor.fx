#define ENABLE_VERTEXCOLOR
#define DISABLE_TEXTURE

#include "2d-sprite-base.fx"