#define ENABLE_ALPHA_BLENDING
#define ENABLE_ALPHA_FACTOR
#define ENABLE_ALPHA_MASK

#include "2d-sprite-base.fx"