#if !defined(DISABLE_TEXTURE)
	#define NEEDS_TEXCOORD0
#endif

#if defined(ENABLE_ALPHA_MASK)
	#define ENABLE_TEXCOORD1
#endif

#if defined(ENABLE_TEXCOORD1)
	#define NEEDS_TEXCOORD1
#endif

#if defined(ENABLE_VERTEXCOLOR) || defined(ENABLE_VERTEXCOLOR_MODULATE)
	#define NEEDS_VERTEXCOLOR
#endif
