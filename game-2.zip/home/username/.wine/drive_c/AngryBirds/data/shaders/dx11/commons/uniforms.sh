matrix WORLDTM;
matrix VIEWTM;
matrix PROJTM;
matrix TOTALTM;

float ALPHA_FACTOR;
float4 DIFFUSEC;
float4 SPECULARC;

