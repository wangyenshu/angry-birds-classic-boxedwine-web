#define ENABLE_VERTEXCOLOR

#include "commons/defines.sh"
#include "commons/attributes.sh"
#include "commons/uniforms.sh"
#include "commons/states.sh"

#include "vertexShaders/2d-sprite-base.vs"
#include "commons/psuniforms.sh"
#include "pixelShaders/2d-sprite-tint.ps"


technique11 Default
{
    pass p0
    {
		SetBlendState( AlphaBlending, float4( 1.0f, 1.0f, 1.0f, 1.0f ), 0xFFFFFFFF );
		SetDepthStencilState( DepthOn, 0 );
		SetRasterizerState( SolidFill );
		
		SetVertexShader( CompileShader( vs_4_0_level_9_1, vsMain() ) );
        SetGeometryShader( NULL );
        SetPixelShader( CompileShader( ps_4_0_level_9_1, psMain() ) );
	}
}
