#define ENABLE_ALPHA_BLENDING

#include "2d-sprite-base.fx"