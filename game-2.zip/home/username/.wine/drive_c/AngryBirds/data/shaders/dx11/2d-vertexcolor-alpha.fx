#define ENABLE_VERTEXCOLOR
#define DISABLE_TEXTURE
#define ENABLE_ALPHA_BLENDING
#define ENABLE_ALPHA_FACTOR

#include "2d-sprite-base.fx"