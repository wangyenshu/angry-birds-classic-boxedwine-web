#define ENABLE_PREMULT_ALPHA_BLENDING
#define ENABLE_ALPHA_FACTOR

#include "2d-sprite-base.fx"