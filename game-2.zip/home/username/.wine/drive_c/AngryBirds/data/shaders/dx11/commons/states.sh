BlendState AlphaBlending
{

#if defined(ENABLE_PREMULT_ALPHA_BLENDING)
	AlphaToCoverageEnable = FALSE;
	BlendEnable[0] = TRUE;
	SrcBlend = ONE;
	DestBlend = INV_SRC_ALPHA;
	BlendOp = ADD;
	SrcBlendAlpha = ONE;
	DestBlendAlpha = INV_SRC_ALPHA;
	BlendOpAlpha = ADD;
	RenderTargetWriteMask[0] = 0x0F;
#elif defined(ENABLE_ALPHA_BLENDING)
	AlphaToCoverageEnable = FALSE;
	BlendEnable[0] = TRUE;
	SrcBlend = SRC_ALPHA;
	DestBlend = INV_SRC_ALPHA;
	BlendOp = ADD;
	SrcBlendAlpha = SRC_ALPHA;
	DestBlendAlpha = INV_SRC_ALPHA;
	BlendOpAlpha = ADD;
	RenderTargetWriteMask[0] = 0x0F;
#elif defined(ENABLE_ALPHA_REVERSED_BLENDING)
	AlphaToCoverageEnable = FALSE;
	BlendEnable[0] = TRUE;
	SrcBlend = INV_SRC_ALPHA;
	DestBlend = SRC_ALPHA;
	BlendOp = ADD;
	SrcBlendAlpha = INV_SRC_ALPHA;
	DestBlendAlpha = SRC_ALPHA;
	BlendOpAlpha = ADD;
	RenderTargetWriteMask[0] = 0x0F;
#else
	AlphaToCoverageEnable = FALSE;
	BlendEnable[0] = FALSE;
	SrcBlend = ONE;
	DestBlend = ZERO;
	BlendOp = ADD;
	SrcBlendAlpha = ONE;
	DestBlendAlpha = ZERO;
	BlendOpAlpha = ADD;
	RenderTargetWriteMask[0] = 0x0F;
#endif

};

DepthStencilState DepthOn
{
	DepthEnable = TRUE;
	DepthWriteMask = ALL;
};

RasterizerState SolidFill 
{ 
	FillMode = Solid;
	CullMode = None;
	ScissorEnable = TRUE;
};

SamplerState SAMPLER
{
    Filter = MIN_MAG_MIP_LINEAR;
    AddressU = Wrap;
    AddressV = Wrap;
};

