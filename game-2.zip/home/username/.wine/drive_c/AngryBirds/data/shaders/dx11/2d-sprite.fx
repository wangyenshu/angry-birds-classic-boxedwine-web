
#include "2d-sprite-base.fx"