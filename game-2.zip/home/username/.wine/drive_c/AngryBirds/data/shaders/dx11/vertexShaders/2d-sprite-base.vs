PixelInputType vsMain(VertexInputType input)
{
	input.position.w = 1.0f;

	PixelInputType output;
	
	output.position = mul(TOTALTM, input.position);

#ifdef NEEDS_TEXCOORD0
	output.texCoord0 = input.texCoord0;
#endif

#ifdef NEEDS_TEXCOORD1
	output.texCoord1 = input.texCoord1;
#endif

#ifdef NEEDS_VERTEXCOLOR
	output.vertexColor = input.vertexColor;
#endif
    
	return output;
}

