struct VertexInputType
{
    float4 position : POSITION;
#if !defined(DISABLE_TEXTURE)
    float2 texCoord0 : TEXCOORD0;
#endif
#if defined(ENABLE_TEXCOORD1)
    float2 texCoord1 : TEXCOORD1;
#endif
#if defined(ENABLE_VERTEXCOLOR) || defined (ENABLE_VERTEXCOLOR_MODULATE)
    float4 vertexColor : COLOR0;
#endif
};

struct PixelInputType
{
    float4 position : SV_POSITION;
#if defined(NEEDS_TEXCOORD0)
    float2 texCoord0 : TEXCOORD0;
#endif	
#if defined(NEEDS_TEXCOORD1)
    float2 texCoord1 : TEXCOORD1;
#endif
#if defined(NEEDS_VERTEXCOLOR)
    float4 vertexColor : COLOR0;
#endif
};
